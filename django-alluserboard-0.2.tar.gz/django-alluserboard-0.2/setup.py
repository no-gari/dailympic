import os
from setuptools import find_packages, setup

with open(os.path.join(os.path.dirname(__file__), 'README')) as readme:
    README = readme.read()

# allow setup.py to be run from any path
os.chdir(os.path.normpath(os.path.join(os.path.abspath(__file__), os.pardir)))

setup(
    name='django-alluserboard',
    version='0.2',
    packages=find_packages(),
	install_requires=[
		'django-filter',
		'django-widget-tweaks',
        'django-summernote',
        'django-simple-history',
		'django-cleanup'
	],
    include_package_data=True,
    license=' License',  # example license
    description='A simple Django board.',
    long_description=README,
    author='alluser.net',
    author_email='alluser.net@gmail.com',
    classifiers=[
        'Environment :: Web Environment',
        'Framework :: Django',
        'Framework :: Django :: 2.1.13',  # replace "X.Y" as appropriate
        'Intended Audience :: Developers',
        'License :: OSI Approved ::  License',  # example license
        'Programming Language :: Python',
        'Programming Language :: Python :: 3.6',
        'Topic :: Internet :: WWW/HTTP',
        'Topic :: Internet :: WWW/HTTP :: Dynamic Content',
    ],
)